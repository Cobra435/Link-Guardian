module.exports = {
    // Bot Profile Status & Token
    botstatus: 'your-status',
    token: 'your-token',
    // Start Up Message & Log Channels
    servername: 'your-server-name',
    startupmessagechannel: 'your-startup-message-channel-id',
    startupmessage: 'your-startup-message',
    logChannelId:'your-log-channel-id',
    // Thumbnails And Images
    thumbnails: 'your-icon-url',
    footers:({ text: 'your-text', iconURL: 'your-icon-url' }),
    // White List Your Links You Want Here
    whitelistedlinks: [
      "your-link-1",
      "your-link-2",
      "yoiur-link-3",
      // Add as many as u like :)
],
};
  